import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import net.proteanit.sql.DbUtils;

public class FlightInfo extends JFrame {
    
    public FlightInfo() {
        
        setTitle("Flight Information");
        getContentPane().setBackground(Color.WHITE);
        setLayout(new BorderLayout());
        
        JTable table = new JTable();
        Color lightSkyBlue = new Color(33, 150, 243); // Light sky blue color
        JTableHeader header = table.getTableHeader();
        header.setBackground(lightSkyBlue);
        header.setForeground(Color.WHITE); // Set text color to white for contrast
        header.setFont(header.getFont().deriveFont(Font.BOLD)); // Make the header text bold
        
        try {
            Conn conn = new Conn();
            ResultSet rs = conn.s.executeQuery("select * from flight");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch(Exception e) {
            e.printStackTrace();
        }
        
        JScrollPane jsp = new JScrollPane(table);
        add(jsp, BorderLayout.CENTER);
        
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        
        JButton refreshButton = new JButton("Refresh");
        refreshButton.setBackground(lightSkyBlue);
        refreshButton.setForeground(Color.WHITE); // Set text color to white for contrast
        refreshButton.addActionListener(e -> {
            try {
                Conn conn = new Conn();
                ResultSet rs = conn.s.executeQuery("select * from flight");
                table.setModel(DbUtils.resultSetToTableModel(rs));
            } catch(Exception ex) {
                ex.printStackTrace();
            }
        });
        
        JButton exitButton = new JButton("Exit");
        exitButton.setBackground(lightSkyBlue);
        exitButton.setForeground(Color.WHITE); // Set text color to white for contrast
        exitButton.addActionListener(e -> System.exit(0));
        
        bottomPanel.add(refreshButton);
        bottomPanel.add(exitButton);
        
        add(bottomPanel, BorderLayout.SOUTH);
        
        setSize(800, 500);
        setLocationRelativeTo(null); // Center the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FlightInfo());
    }
}