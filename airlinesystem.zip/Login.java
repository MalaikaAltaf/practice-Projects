import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class Login {
    private static final String DB_URL = "jdbc:mysql:///airlinesystem1";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "root1122";

    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField emailField;
    private JTextArea messageArea;

    public Login() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Airline Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null); // Center the frame
        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Styling
        Font labelFont = new Font("Arial", Font.BOLD, 14);
        Font textFieldFont = new Font("Arial", Font.PLAIN, 14);
        Color buttonColor = new Color(33, 150, 243); // Blue color for buttons
        Color buttonTextColor = Color.WHITE;

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(labelFont);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        frame.add(usernameLabel, gbc);

        usernameField = new JTextField();
        usernameField.setFont(textFieldFont);
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        frame.add(usernameField, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(labelFont);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        frame.add(passwordLabel, gbc);

        passwordField = new JPasswordField();
        passwordField.setFont(textFieldFont);
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        frame.add(passwordField, gbc);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(labelFont);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        frame.add(emailLabel, gbc);

        emailField = new JTextField();
        emailField.setFont(textFieldFont);
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        frame.add(emailField, gbc);

        JButton signUpButton = new JButton("Sign Up");
        signUpButton.setFont(textFieldFont);
        signUpButton.setBackground(buttonColor);
        signUpButton.setForeground(buttonTextColor);
        signUpButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20)); // Padding inside the button
        signUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                signUp(usernameField.getText(), new String(passwordField.getPassword()), emailField.getText());
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        frame.add(signUpButton, gbc);

        JButton signInButton = new JButton("Sign In");
        signInButton.setFont(textFieldFont);
        signInButton.setBackground(buttonColor);
        signInButton.setForeground(buttonTextColor);
        signInButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        signInButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                signIn(usernameField.getText(), new String(passwordField.getPassword()));
            }
        });
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        frame.add(signInButton, gbc);

        messageArea = new JTextArea(3, 20);
        messageArea.setEditable(false);
        messageArea.setFont(textFieldFont);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(messageArea);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        frame.add(scrollPane, gbc);

        frame.setVisible(true);
    }

    public void signUp(String username, String password, String email) {
        if (!isValidEmail(email)) {
            messageArea.setText("Invalid Email format. Please use a Gmail address (e.g., example@gmail.com).");
            return;
        }

        String insertQuery = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);
            pstmt.setString(3, email);
            pstmt.executeUpdate();
            messageArea.setText("Sign up successful.");

        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) {
                messageArea.setText("Username already exists.");
            } else {
                e.printStackTrace();
                messageArea.setText("Error: " + e.getMessage());
            }
        }
    }

    public boolean signIn(String username, String password) {
        String selectQuery = "SELECT * FROM users WHERE username = ? AND password = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectQuery)) {

            pstmt.setString(1, username);
            pstmt.setString(2, password);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                messageArea.setText("Sign in successful.");
                new Home(); // Assuming Home is another class you have
                return true;
            } else {
                messageArea.setText("Invalid username or password.");
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            messageArea.setText("Error: " + e.getMessage());
            return false;
        }
    }

    private boolean isValidEmail(String email) {
        // Regex pattern to match Gmail addresses
        String emailPattern = "^[a-zA-Z0-9._%+-]+@gmail\\.com$";
        return Pattern.matches(emailPattern, email);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Login();
            }
        });
    }
}